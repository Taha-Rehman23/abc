#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdio.h>

int main()
{

int fd;
char Buffer[1024];

fd=open("data.txt",O_RDONLY);

if(fd==-1)
{
printf("File Descriptor no: %d \n",fd);
}

if(read(fd,Buffer,sizeof(Buffer))==-1)
{
printf("read() Error Occures");
}

printf("Data Extrected from file is here: %s",Buffer);
close(fd);

return 0;

}
