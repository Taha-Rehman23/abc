#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<unistd.h>
#include<stdio.h>

int main(void)
{

int fd;
char Buffer[]="Let's Implement this code too taha boy\n";

fd=open("data.txt",O_CREAT|O_WRONLY|O_TRUNC);

if(fd==-1)
{
printf("open() error Occurs");
}

printf("file descriptor no: %d\n",fd);

if(write(fd,Buffer, sizeof(Buffer))==-1)
{
printf("write() error Occurs");
}
close(fd);

return 0;

}

